#include <string>
#include <iostream>
#include "Produto.h"

class OrdenarStrategy{
    protected:
    
    std::vector<Produto> _p1;
    
    public:
    
    OrdenarStrategy(std::vector<Produto> p1 ) : _p1(p1){}
    
    virtual ~OrdenarStrategy(){}
    
    virtual void ordenar() = 0;
    
    
};