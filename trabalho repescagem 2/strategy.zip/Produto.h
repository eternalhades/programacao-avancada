#include <string>
#include <iostream>
#pragma once
class Produto{
    int _prioridade;
    std::string _nome;
    int _preco;
   

    public:
    Produto( int prioridade, std::string nome, int  preco) : _prioridade(prioridade), _nome(nome), _preco(preco){}
        const int getPrioridade() const {
        return _prioridade;
    }
    const std::string &getNome() const {
        return _nome;
    }
     const int getPreco() const {
        return _preco;
    }
    void setPrioridade( int prioridade) {
        _prioridade= prioridade;
    }
    void setNome(const std::string &nome) {
        _nome= nome;
    }
    void setPreco(const  int preco) {
        _preco = preco;
    }
    
};
