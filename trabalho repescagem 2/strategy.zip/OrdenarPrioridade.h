#include <string>
#include <iostream>
#include "Produto.h"
#include "Strategy.h"

class OrdenarPrioridade: public OrdenarStrategy{
    public:
        OrdenarPrioridade(std::vector <Produto> p1) : OrdenarStrategy(p1){}
        
        virtual ~OrdenarPrioridade(){}
        
        virtual bool ordenar(Produto A, Produto B){
            if (A.getPrioridade() > B.getPrioridade())
            return true;
            return false;
        }
        
};
