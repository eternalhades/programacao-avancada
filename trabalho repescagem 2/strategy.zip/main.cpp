#include <iostream>
#include <string>


#include "Produto.h"
#include <vector>
#include <deque>
#include <list>
#include "OrdenaNome.h"
#include <algorithm>

using namespace std;
int main()

{   Produto p1(1,"awqe", 1);
    return 0;
    
    vector<Produto> v1;
 
    
    v1.push_back(Produto(1, "produto 1", 3213300));
    v1.push_back(Produto(2, "produto 2", 300));
    v1.push_back(Produto(3, "produto 3", 30220));
    v1.push_back(Produto(2, "aaa", 210));
    v1.push_back(Produto(5, "b", 420));
    v1.push_back(Produto(3, "c", 300));
    
    OrdenarNome s1(v1);
}



