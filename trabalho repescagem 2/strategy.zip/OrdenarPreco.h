#include <string>
#include <iostream>
#include "Produto.h"
#include "Strategy.h"

class OrdenarPreco: public OrdenarStrategy{
    public:
        OrdenarPreco(std::vector <Produto> p1) : OrdenarStrategy(p1){}
        
        virtual ~OrdenarPreco(){}
        
        virtual bool ordenar(Produto A, Produto B){
            if (A.getPreco() > B.getPreco())
            return true;
            return false;
        }
        
};
