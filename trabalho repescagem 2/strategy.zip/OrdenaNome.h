
#include <iostream>
#include "Produto.h"
#include "Strategy.h"

class OrdenarNome : public OrdenarStrategy{
    public:
        OrdenarNome(std::vector <Produto> p1) : OrdenarStrategy(p1){}
        
        virtual ~OrdenarNome(){}
        
        virtual bool ordenar(Produto A, Produto B){
            if (A.getNome() > B.getNome())
            return true;
            return false;
        }
        
};
